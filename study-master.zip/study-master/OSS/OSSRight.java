package com.up.utils;

public class LzOosBi {
    //阿里云API的外网域名
    public static final String ENDPOINT = "oss-cn-beijing.aliyuncs.com";
    //阿里云API的密钥Access Key ID
    public static final String ACCESS_KEY_ID = "ACCESS_KEY_ID";
    //阿里云API的密钥Access Key Secret
    public static final String ACCESS_KEY_SECRET = "ACCESS_KEY_SECRET";
    //阿里云API的bucket名称
    public static final String BACKET_NAME = "BACKET_NAME";
    //阿里云API的文件夹名称
    public static final String FOLDER = "FOLDER/";

}
